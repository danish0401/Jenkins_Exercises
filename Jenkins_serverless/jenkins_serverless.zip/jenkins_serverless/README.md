<!--
title: 'AWS Python Example'
description: 'This template demonstrates how to deploy a Python function running on AWS Lambda using the traditional Serverless Framework.'
layout: Doc
framework: v3
platform: AWS
language: python
priority: 2
authorLink: 'https://github.com/serverless'
authorName: 'Serverless, inc.'
authorAvatar: 'https://avatars1.githubusercontent.com/u/13742415?s=200&v=4'
-->


# Serverless Framework Deployment of Python Example using Jenkins pipeline jobs
## Pre Requisites:
### Step 1: Install NodeJs Pluggin in jenkins server
For Nodejs to run you must install a Nodejs plugin.
The plugin panel can be accessed through
* Manage Jenkins > Manage Plugins
* From here select the available tab. Instead of scrolling the list just search Nodejs at the top right-hand corner.
* Select and install the plugin in. This may take a few moments.

### Step 2: Global Tool Configuration
After the installation has finished you must configure the Nodejs in Jenkins. 
To do this 
* go to “Manage Jenkins”. Then Global Tool Configuration. 
* Scroll down to Nodejs select the “Add NodeJS”. 
* File in the form name :NodeJS and select the intend Nodejs version(I used 16.00). 
* Save the setting.

### Step 3: Configuring Jenkins Credentials For Git
Steps to do this task are given:
* Click on the Manage Jenkins option
* Go to Manage Credentials under Security
* system -> Global credentials -> Add Credentials
* here add git username and password(Git token) and give it some ID(this ID is used in pipeline script)

you are good to go and deploy the script.

### Step 4: Create a Jenkins Job
Create a new jenkins pipeline job and add the Script written in Jenkinsfile.
Script is divided in 3 stages
* Stage 1: clone the git repo which contains serverless.yml and handler files
* Stage 2: install serverless cli using npm
* Stage 3: Deploy the serverles app.

Note: I setupped Jenkins on EC2 and gave EC2 roles to access lambda and cloudformation.


##### Details of serverless Deployment

In Jenkins script, you need to run the following command:

```
$ serverless deploy
```

After running deploy, you should see output similar to:

```bash
Deploying aws-python-project to stage dev (us-east-1)

✔ Service deployed to stack aws-python-project-dev (112s)

functions:
  hello: aws-python-project-dev-hello (1.5 kB)
```